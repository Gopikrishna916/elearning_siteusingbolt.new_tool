import { utils, writeFile } from 'xlsx';
import { unparse } from 'papaparse';
import type { ExamResult } from '../types';

export const exportToExcel = (results: ExamResult[]) => {
  const worksheet = utils.json_to_sheet(results);
  const workbook = utils.book_new();
  utils.book_append_sheet(workbook, worksheet, 'Exam Results');
  writeFile(workbook, 'exam-results.xlsx');
};

export const exportToCSV = (results: ExamResult[]) => {
  const csv = unparse(results);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'exam-results.csv';
  link.click();
};