import { jsPDF } from 'jspdf';
import type { Certificate } from '../types';

export const generateCertificate = async (certificate: Certificate) => {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4'
  });

  // Set background color
  doc.setFillColor(16, 39, 68); // navy-800
  doc.rect(0, 0, 297, 210, 'F');

  // Add decorative border
  doc.setDrawColor(59, 130, 246); // blue-500
  doc.setLineWidth(2);
  doc.rect(10, 10, 277, 190);

  // Add logo
  // In a real app, you'd use a real logo
  doc.setTextColor(59, 130, 246);
  doc.setFontSize(40);
  doc.text('Syncornota', 148.5, 40, { align: 'center' });

  // Certificate title
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(30);
  doc.text('Certificate of Completion', 148.5, 70, { align: 'center' });

  // Certificate text
  doc.setFontSize(16);
  doc.text('This is to certify that', 148.5, 90, { align: 'center' });
  
  // Student name
  doc.setFontSize(24);
  doc.setTextColor(59, 130, 246);
  doc.text(certificate.userId, 148.5, 105, { align: 'center' });

  // Course details
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.text('has successfully completed the course', 148.5, 120, { align: 'center' });
  
  doc.setFontSize(20);
  doc.setTextColor(59, 130, 246);
  doc.text(certificate.courseName, 148.5, 135, { align: 'center' });

  // Grade and date
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.text(`with grade: ${certificate.grade}`, 148.5, 150, { align: 'center' });
  doc.text(`Issue Date: ${certificate.issueDate}`, 148.5, 160, { align: 'center' });
  doc.text(`Certificate Number: ${certificate.certificateNumber}`, 148.5, 170, { align: 'center' });

  // Signature
  doc.setTextColor(59, 130, 246);
  doc.text('Raju Mitra Kanacheti', 148.5, 185, { align: 'center' });
  doc.setFontSize(12);
  doc.setTextColor(255, 255, 255);
  doc.text('CEO, Syncornota', 148.5, 192, { align: 'center' });

  return doc;
};

export const downloadCertificate = async (certificate: Certificate) => {
  const doc = await generateCertificate(certificate);
  doc.save(`${certificate.courseName.toLowerCase().replace(/\s+/g, '-')}-certificate.pdf`);
};