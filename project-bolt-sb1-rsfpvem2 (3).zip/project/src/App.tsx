import React, { useState } from 'react';
import { AuthForm } from './components/AuthForm';
import { ExamInterface } from './components/ExamInterface';
import { ExamResults } from './components/ExamResults';
import { EmployeePanel } from './components/EmployeePanel';
import { ModuleContent } from './components/ModuleContent';
import { HomePage } from './components/HomePage';
import type { User } from './types';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [showExam, setShowExam] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [selectedModule, setSelectedModule] = useState<string | null>(null);

  const handleLogin = (email: string, password: string, role: 'student' | 'employee') => {
    setUser({
      id: '1',
      email,
      role,
      name: 'John Doe'
    });
  };

  const modules = [
    {
      id: 'genai',
      title: 'Generative AI',
      description: 'Learn about Large Language Models, Diffusion Models, and Transformers',
      topics: ['Transformers Architecture', 'Prompt Engineering', 'LLM Training', 'Text-to-Image Models'],
      image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995'
    },
    {
      id: 'ai',
      title: 'Artificial Intelligence',
      description: 'Fundamentals of AI, Search Algorithms, and Knowledge Representation',
      topics: ['Search Algorithms', 'Expert Systems', 'Game Theory', 'Natural Language Processing'],
      image: 'https://images.unsplash.com/photo-1555255707-c07966088b7b'
    },
    {
      id: 'ml',
      title: 'Machine Learning',
      description: 'Statistical Learning, Supervised and Unsupervised Learning',
      topics: ['Regression', 'Classification', 'Clustering', 'Dimensionality Reduction'],
      image: 'https://images.unsplash.com/photo-1527474305487-b87b222841cc'
    },
    {
      id: 'dl',
      title: 'Deep Learning',
      description: 'Neural Networks, CNN, RNN, and Advanced Architectures',
      topics: ['Neural Networks', 'CNN', 'RNN', 'LSTM', 'GAN'],
      image: 'https://images.unsplash.com/photo-1501854140801-50d01698950b'
    },
    {
      id: 'anns',
      title: 'Artificial Neural Networks',
      description: 'Deep dive into neural network architectures and training',
      topics: ['Perceptrons', 'Backpropagation', 'Activation Functions', 'Network Optimization'],
      image: 'https://images.unsplash.com/photo-1620712943543-bcc4688e7485'
    }
  ];

  const mockExam = {
    title: "Generative AI and Prompt Engineering",
    duration: 60,
    questions: [
      {
        text: "Which component is central to the architecture of transformer models?",
        options: [
          "Self-attention mechanism",
          "Convolutional layers",
          "Pooling layers",
          "Recurrent connections"
        ],
        correctAnswer: 0
      },
      {
        text: "What is the primary purpose of prompt engineering?",
        options: [
          "To optimize model responses",
          "To write code faster",
          "To debug neural networks",
          "To compress data"
        ],
        correctAnswer: 0
      },
      {
        text: "Which of these is NOT a common type of attention mechanism?",
        options: [
          "Linear attention",
          "Multi-head attention",
          "Self-attention",
          "Cross-attention"
        ],
        correctAnswer: 0
      },
      {
        text: "What is the role of temperature in text generation?",
        options: [
          "Controls randomness of outputs",
          "Affects model training speed",
          "Determines batch size",
          "Regulates learning rate"
        ],
        correctAnswer: 0
      },
      {
        text: "Which technique is used in stable diffusion models?",
        options: [
          "Denoising diffusion",
          "Gradient descent",
          "Backpropagation",
          "Forward propagation"
        ],
        correctAnswer: 0
      }
    ]
  };

  const calculateResults = (answers: number[]) => {
    let score = 0;
    const detailedAnswers = mockExam.questions.map((question, index) => {
      const isCorrect = answers[index] === question.correctAnswer;
      if (isCorrect) score++;
      
      return {
        question: question.text,
        userAnswer: question.options[answers[index]],
        correctAnswer: question.options[question.correctAnswer],
        isCorrect
      };
    });

    return {
      score,
      totalQuestions: mockExam.questions.length,
      answers: detailedAnswers
    };
  };

  if (!user) {
    return <HomePage modules={modules} onLogin={handleLogin} />;
  }

  if (user.role === 'employee') {
    return (
      <div className="min-h-screen bg-navy-900 text-white">
        <nav className="bg-navy-800 px-6 py-4 shadow-lg">
          <div className="max-w-6xl mx-auto flex justify-between items-center">
            <h1 className="text-xl font-bold text-blue-400">Syncornota Employee Portal</h1>
            <div className="flex items-center space-x-4">
              <span className="text-gray-300">{user.email}</span>
              <button
                onClick={() => setUser(null)}
                className="px-4 py-2 bg-navy-700 rounded-lg hover:bg-navy-600"
              >
                Logout
              </button>
            </div>
          </div>
        </nav>
        <EmployeePanel />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-900 text-white">
      <nav className="bg-navy-800 px-6 py-4 shadow-lg mb-8">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold text-blue-400">Syncornota Learning Portal</h1>
          <div className="flex items-center space-x-4">
            <span className="text-gray-300">{user.email}</span>
            <button
              onClick={() => setUser(null)}
              className="px-4 py-2 bg-navy-700 rounded-lg hover:bg-navy-600"
            >
              Logout
            </button>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-4">
        {!showExam && !showResults && !selectedModule ? (
          <div>
            <h2 className="text-2xl font-bold mb-6">Learning Modules</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {modules.map(module => (
                <div
                  key={module.id}
                  className="bg-navy-800 rounded-lg p-6 hover:bg-navy-700 transition-colors cursor-pointer"
                  onClick={() => setSelectedModule(module.id)}
                >
                  <div className="h-48 mb-4 overflow-hidden rounded-lg">
                    <img 
                      src={module.image} 
                      alt={module.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-xl font-bold text-blue-400 mb-2">{module.title}</h3>
                  <p className="text-gray-300 mb-4">{module.description}</p>
                  <ul className="text-gray-400 space-y-1">
                    {module.topics.map(topic => (
                      <li key={topic}>• {topic}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            <div className="mt-8 p-6 bg-navy-800 rounded-lg">
              <h3 className="text-xl font-bold text-blue-400 mb-4">Next Scheduled Exam</h3>
              <p className="text-gray-300 mb-4">
                Weekly GenAI Assessment - Every Friday at 2:00 PM
              </p>
              <button
                onClick={() => setShowExam(true)}
                className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Start Practice Exam
              </button>
            </div>
          </div>
        ) : selectedModule && !showExam && !showResults ? (
          <ModuleContent
            module={modules.find(m => m.id === selectedModule)!}
            onBack={() => setSelectedModule(null)}
            onStartExam={() => setShowExam(true)}
          />
        ) : showExam ? (
          <ExamInterface
            exam={mockExam}
            onSubmit={(answers) => {
              setUserAnswers(answers);
              setShowExam(false);
              setShowResults(true);
            }}
          />
        ) : (
          <ExamResults
            {...calculateResults(userAnswers)}
          />
        )}
      </div>
    </div>
  );
}