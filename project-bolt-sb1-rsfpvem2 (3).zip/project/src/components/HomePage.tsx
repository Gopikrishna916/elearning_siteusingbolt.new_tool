import React, { useState, useEffect } from 'react';
import { AuthForm } from './AuthForm';
import { Brain, GraduationCap, Users, Award, ArrowRight, ArrowLeft } from 'lucide-react';

interface HomePageProps {
  modules: Array<{
    id: string;
    title: string;
    description: string;
    image: string;
  }>;
  onLogin: (email: string, password: string, role: 'student' | 'admin') => void;
}

export function HomePage({ modules, onLogin }: HomePageProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showLogin, setShowLogin] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % modules.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [modules.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % modules.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + modules.length) % modules.length);
  };

  return (
    <div className="min-h-screen bg-navy-900">
      {/* Header */}
      <header className="bg-navy-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Brain className="h-8 w-8 text-blue-400" />
              <h1 className="ml-2 text-2xl font-bold text-white">Syncornota</h1>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={() => setShowLogin(true)}
                className="px-4 py-2 text-white hover:text-blue-400 transition-colors"
              >
                Login
              </button>
              <button
                onClick={() => setShowLogin(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Register
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section with Slider */}
      <div className="relative h-[500px] overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-in-out h-full"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {modules.map((module, index) => (
            <div
              key={module.id}
              className="min-w-full h-full relative"
            >
              <img
                src={module.image}
                alt={module.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-navy-900/90 to-navy-900/50 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                  <h2 className="text-4xl font-bold text-white mb-4">{module.title}</h2>
                  <p className="text-xl text-gray-300 mb-8">{module.description}</p>
                  <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                    Learn More
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <button
          onClick={prevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-navy-800/50 rounded-full hover:bg-navy-800/80 transition-colors"
        >
          <ArrowLeft className="w-6 h-6 text-white" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-navy-800/50 rounded-full hover:bg-navy-800/80 transition-colors"
        >
          <ArrowRight className="w-6 h-6 text-white" />
        </button>
      </div>

      {/* Features Section */}
      <section className="py-16 bg-navy-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-white mb-12">Why Choose Syncornota?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <GraduationCap className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Expert-Led Courses</h3>
              <p className="text-gray-300">Learn from industry professionals and experienced educators</p>
            </div>
            <div className="text-center p-6">
              <Users className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Interactive Learning</h3>
              <p className="text-gray-300">Engage with peers and instructors in real-time discussions</p>
            </div>
            <div className="text-center p-6">
              <Award className="w-12 h-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-white mb-2">Certified Programs</h3>
              <p className="text-gray-300">Earn recognized certificates upon course completion</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy-900 border-t border-navy-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-bold text-white mb-4">About Us</h3>
              <p className="text-gray-400">Empowering learners with cutting-edge AI education and certification programs.</p>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-blue-400">Courses</a></li>
                <li><a href="#" className="hover:text-blue-400">Schedule</a></li>
                <li><a href="#" className="hover:text-blue-400">Testimonials</a></li>
                <li><a href="#" className="hover:text-blue-400">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@syncornota.com</li>
                <li>Phone: +1 (555) 123-4567</li>
                <li>Address: 123 Learning Street</li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-blue-400">Twitter</a>
                <a href="#" className="text-gray-400 hover:text-blue-400">LinkedIn</a>
                <a href="#" className="text-gray-400 hover:text-blue-400">Facebook</a>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-navy-800 text-center text-gray-400">
            <p>&copy; 2024 Syncornota. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Login/Register Modal */}
      {showLogin && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="relative">
            <button
              onClick={() => setShowLogin(false)}
              className="absolute top-2 right-2 text-gray-400 hover:text-white"
            >
              ×
            </button>
            <AuthForm onSubmit={onLogin} />
          </div>
        </div>
      )}
    </div>
  );
}