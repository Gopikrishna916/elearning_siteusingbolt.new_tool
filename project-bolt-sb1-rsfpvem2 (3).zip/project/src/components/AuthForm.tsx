import React, { useState } from 'react';
import { LogIn } from 'lucide-react';

interface AuthFormProps {
  onSubmit: (email: string, password: string, role: 'student' | 'employee') => void;
}

export function AuthForm({ onSubmit }: AuthFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'student' | 'employee'>('student');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(email, password, role);
  };

  return (
    <div className="w-full max-w-md p-8 bg-navy-800 rounded-lg shadow-xl">
      <div className="flex items-center justify-center mb-8">
        <LogIn className="w-8 h-8 text-blue-400" />
        <h2 className="ml-2 text-2xl font-bold text-white">Exam Portal Login</h2>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-300">Role</label>
          <div className="mt-2 flex gap-4">
            <label className="flex items-center">
              <input
                type="radio"
                value="student"
                checked={role === 'student'}
                onChange={(e) => setRole(e.target.value as 'student' | 'employee')}
                className="text-blue-500"
              />
              <span className="ml-2 text-white">Student</span>
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                value="employee"
                checked={role === 'employee'}
                onChange={(e) => setRole(e.target.value as 'student' | 'employee')}
                className="text-blue-500"
              />
              <span className="ml-2 text-white">Employee</span>
            </label>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition duration-200"
        >
          Login
        </button>
      </form>
    </div>
  );
}