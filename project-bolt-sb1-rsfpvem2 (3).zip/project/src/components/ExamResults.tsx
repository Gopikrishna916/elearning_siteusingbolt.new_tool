import React from 'react';
import { CheckCircle, XCircle, BarChart } from 'lucide-react';

interface ExamResultsProps {
  score: number;
  totalQuestions: number;
  answers: {
    question: string;
    userAnswer: string;
    correctAnswer: string;
    isCorrect: boolean;
  }[];
}

export function ExamResults({ score, totalQuestions, answers }: ExamResultsProps) {
  const percentage = (score / totalQuestions) * 100;

  return (
    <div className="max-w-4xl mx-auto p-6 bg-navy-800 rounded-lg shadow-xl">
      <div className="text-center mb-8">
        <BarChart className="w-12 h-12 text-blue-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">Exam Results</h2>
        <div className="text-4xl font-bold text-blue-400 mb-2">{percentage.toFixed(1)}%</div>
        <p className="text-gray-300">
          You scored {score} out of {totalQuestions} questions correctly
        </p>
      </div>

      <div className="space-y-6">
        {answers.map((answer, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg ${
              answer.isCorrect ? 'bg-navy-700/50' : 'bg-red-900/20'
            }`}
          >
            <div className="flex items-start">
              <div className="mr-4">
                {answer.isCorrect ? (
                  <CheckCircle className="w-6 h-6 text-green-500" />
                ) : (
                  <XCircle className="w-6 h-6 text-red-500" />
                )}
              </div>
              <div className="flex-1">
                <p className="text-white mb-2">{answer.question}</p>
                <div className="text-sm">
                  <p className="text-gray-400">Your answer: {answer.userAnswer}</p>
                  {!answer.isCorrect && (
                    <p className="text-green-400">Correct answer: {answer.correctAnswer}</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}