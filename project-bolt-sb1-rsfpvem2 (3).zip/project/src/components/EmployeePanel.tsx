import React, { useState } from 'react';
import { PlusCircle, Clock, Users, FileText } from 'lucide-react';
import type { Exam, ExamResult } from '../types';

export function EmployeePanel() {
  const [activeTab, setActiveTab] = useState<'create' | 'results'>('create');

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex space-x-4 mb-8">
        <button
          onClick={() => setActiveTab('create')}
          className={`flex items-center px-4 py-2 rounded-lg ${
            activeTab === 'create'
              ? 'bg-blue-600 text-white'
              : 'bg-navy-700 text-gray-300 hover:bg-navy-600'
          }`}
        >
          <PlusCircle className="w-5 h-5 mr-2" />
          Create Exam
        </button>
        <button
          onClick={() => setActiveTab('results')}
          className={`flex items-center px-4 py-2 rounded-lg ${
            activeTab === 'results'
              ? 'bg-blue-600 text-white'
              : 'bg-navy-700 text-gray-300 hover:bg-navy-600'
          }`}
        >
          <FileText className="w-5 h-5 mr-2" />
          Results Analysis
        </button>
      </div>

      {activeTab === 'create' ? (
        <div className="bg-navy-800 rounded-lg p-6 shadow-xl">
          <h2 className="text-2xl font-bold text-white mb-6">Create New Exam</h2>
          <form className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Exam Title
              </label>
              <input
                type="text"
                className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                placeholder="Enter exam title"
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Duration (minutes)
                </label>
                <input
                  type="number"
                  className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                  placeholder="60"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Start Time
                </label>
                <input
                  type="datetime-local"
                  className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Questions
              </label>
              <div className="space-y-4">
                {/* Question input fields would go here */}
                <button
                  type="button"
                  className="w-full py-2 px-4 bg-navy-700 text-white rounded-md hover:bg-navy-600 flex items-center justify-center"
                >
                  <PlusCircle className="w-5 h-5 mr-2" />
                  Add Question
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition duration-200"
            >
              Create Exam
            </button>
          </form>
        </div>
      ) : (
        <div className="bg-navy-800 rounded-lg p-6 shadow-xl">
          <h2 className="text-2xl font-bold text-white mb-6">Results Analysis</h2>
          <div className="grid grid-cols-3 gap-6 mb-8">
            <div className="bg-navy-700 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-6 h-6 text-blue-400" />
                <span className="text-2xl font-bold text-white">42</span>
              </div>
              <p className="text-gray-300">Total Students</p>
            </div>
            <div className="bg-navy-700 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <FileText className="w-6 h-6 text-blue-400" />
                <span className="text-2xl font-bold text-white">8</span>
              </div>
              <p className="text-gray-300">Active Exams</p>
            </div>
            <div className="bg-navy-700 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <Clock className="w-6 h-6 text-blue-400" />
                <span className="text-2xl font-bold text-white">85%</span>
              </div>
              <p className="text-gray-300">Average Score</p>
            </div>
          </div>

          {/* Results table would go here */}
          <div className="bg-navy-900 rounded-lg overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-navy-700">
                <tr>
                  <th className="px-6 py-3 text-gray-300">Exam Title</th>
                  <th className="px-6 py-3 text-gray-300">Date</th>
                  <th className="px-6 py-3 text-gray-300">Students</th>
                  <th className="px-6 py-3 text-gray-300">Avg. Score</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-navy-700">
                {/* Sample data rows */}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}