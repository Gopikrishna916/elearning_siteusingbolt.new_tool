import React, { useState, useEffect } from 'react';
import { Clock, ChevronLeft, ChevronRight } from 'lucide-react';

interface ExamInterfaceProps {
  exam: {
    title: string;
    duration: number;
    questions: Array<{
      text: string;
      options: string[];
    }>;
  };
  onSubmit: (answers: number[]) => void;
}

export function ExamInterface({ exam, onSubmit }: ExamInterfaceProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>(new Array(exam.questions.length).fill(-1));
  const [timeLeft, setTimeLeft] = useState(exam.duration * 60);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onSubmit(answers);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [answers, onSubmit, exam.duration]);

  const handleAnswer = (optionIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionIndex;
    setAnswers(newAnswers);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-navy-800 rounded-lg shadow-xl">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold text-white">{exam.title}</h2>
        <div className="flex items-center text-blue-400">
          <Clock className="w-5 h-5 mr-2" />
          <span>{formatTime(timeLeft)}</span>
        </div>
      </div>

      <div className="mb-8">
        <div className="text-lg text-white mb-4">
          Question {currentQuestion + 1} of {exam.questions.length}
        </div>
        <p className="text-xl text-white mb-6">{exam.questions[currentQuestion].text}</p>

        <div className="space-y-4">
          {exam.questions[currentQuestion].options.map((option, index) => (
            <label
              key={index}
              className={`block p-4 rounded-lg cursor-pointer transition-colors ${
                answers[currentQuestion] === index
                  ? 'bg-blue-600 text-white'
                  : 'bg-navy-900 text-gray-300 hover:bg-navy-700'
              }`}
            >
              <input
                type="radio"
                name="answer"
                className="hidden"
                checked={answers[currentQuestion] === index}
                onChange={() => handleAnswer(index)}
              />
              {option}
            </label>
          ))}
        </div>
      </div>

      <div className="flex justify-between">
        <button
          onClick={() => setCurrentQuestion((prev) => Math.max(0, prev - 1))}
          disabled={currentQuestion === 0}
          className="flex items-center px-4 py-2 bg-navy-700 text-white rounded-lg disabled:opacity-50"
        >
          <ChevronLeft className="w-5 h-5 mr-1" />
          Previous
        </button>

        {currentQuestion === exam.questions.length - 1 ? (
          <button
            onClick={() => onSubmit(answers)}
            className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
          >
            Submit Exam
          </button>
        ) : (
          <button
            onClick={() => setCurrentQuestion((prev) => Math.min(exam.questions.length - 1, prev + 1))}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg"
          >
            Next
            <ChevronRight className="w-5 h-5 ml-1" />
          </button>
        )}
      </div>
    </div>
  );
}