import React, { useState } from 'react';
import { PlusCircle, Clock, Users, FileText, Download, Timer, Settings, BarChart2, Calendar, Book, Award } from 'lucide-react';

interface Question {
  text: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
}

interface ExamTemplate {
  id: string;
  title: string;
  questions: Question[];
  duration: number;
  passingScore: number;
  category: string;
}

export function AdminPanel() {
  const [activeTab, setActiveTab] = useState<'create' | 'results' | 'templates' | 'analytics'>('create');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [examTemplates, setExamTemplates] = useState<ExamTemplate[]>([]);
  const [examSettings, setExamSettings] = useState({
    title: '',
    duration: 60,
    startTime: '',
    passingScore: 70,
    allowReview: true,
    shuffleQuestions: false,
    timePerQuestion: 2,
    showProgress: true,
    preventTabSwitch: true,
    requireWebcam: false,
    category: 'GenAI',
    difficulty: 'medium'
  });

  const handleAddQuestion = () => {
    setQuestions([
      ...questions,
      {
        text: '',
        options: ['', '', '', ''],
        correctAnswer: 0,
        explanation: '',
        difficulty: 'medium',
        points: 10
      }
    ]);
  };

  const handleQuestionChange = (index: number, field: string, value: any) => {
    const newQuestions = [...questions];
    newQuestions[index] = { ...newQuestions[index], [field]: value };
    setQuestions(newQuestions);
  };

  const handleSaveTemplate = () => {
    const newTemplate: ExamTemplate = {
      id: Date.now().toString(),
      title: examSettings.title,
      questions: questions,
      duration: examSettings.duration,
      passingScore: examSettings.passingScore,
      category: examSettings.category
    };
    setExamTemplates([...examTemplates, newTemplate]);
  };

  const handleDownloadResults = () => {
    // In a real application, this would generate and download a CSV/Excel file
    alert('Downloading results...');
  };

  const renderAnalytics = () => (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-navy-700 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <Users className="w-8 h-8 text-blue-400" />
            <span className="text-3xl font-bold">156</span>
          </div>
          <h3 className="text-lg font-medium">Active Students</h3>
          <p className="text-sm text-gray-400">+12% from last month</p>
        </div>
        <div className="bg-navy-700 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <Award className="w-8 h-8 text-green-400" />
            <span className="text-3xl font-bold">89%</span>
          </div>
          <h3 className="text-lg font-medium">Pass Rate</h3>
          <p className="text-sm text-gray-400">+5% from last month</p>
        </div>
        <div className="bg-navy-700 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <Book className="w-8 h-8 text-purple-400" />
            <span className="text-3xl font-bold">24</span>
          </div>
          <h3 className="text-lg font-medium">Active Courses</h3>
          <p className="text-sm text-gray-400">3 new this month</p>
        </div>
        <div className="bg-navy-700 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <Calendar className="w-8 h-8 text-yellow-400" />
            <span className="text-3xl font-bold">8</span>
          </div>
          <h3 className="text-lg font-medium">Upcoming Exams</h3>
          <p className="text-sm text-gray-400">Next: Friday 2 PM</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-navy-700 p-6 rounded-lg">
          <h3 className="text-xl font-bold mb-4">Performance by Module</h3>
          <div className="space-y-4">
            {['GenAI', 'Machine Learning', 'Deep Learning', 'Neural Networks'].map(module => (
              <div key={module} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>{module}</span>
                  <span>78%</span>
                </div>
                <div className="w-full bg-navy-900 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full" 
                    style={{ width: '78%' }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-navy-700 p-6 rounded-lg">
          <h3 className="text-xl font-bold mb-4">Student Engagement</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Average Study Time</span>
              <span className="text-blue-400">4.2 hours/week</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Assignment Completion</span>
              <span className="text-green-400">92%</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Practice Tests Taken</span>
              <span className="text-purple-400">245 this month</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Active Discussion Threads</span>
              <span className="text-yellow-400">32</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-navy-700 p-6 rounded-lg">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold">Recent Exam Results</h3>
          <button
            onClick={handleDownloadResults}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Download className="w-5 h-5 mr-2" />
            Export Data
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left border-b border-navy-600">
                <th className="pb-3">Student</th>
                <th className="pb-3">Exam</th>
                <th className="pb-3">Score</th>
                <th className="pb-3">Date</th>
                <th className="pb-3">Status</th>
              </tr>
            </thead>
            <tbody className="text-gray-300">
              {[1, 2, 3, 4, 5].map(i => (
                <tr key={i} className="border-b border-navy-600">
                  <td className="py-3">Student {i}</td>
                  <td className="py-3">GenAI Fundamentals</td>
                  <td className="py-3">{85 + i}%</td>
                  <td className="py-3">2024-03-{15 + i}</td>
                  <td className="py-3">
                    <span className="px-2 py-1 bg-green-600/20 text-green-400 rounded">
                      Passed
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex space-x-4 mb-8">
        <button
          onClick={() => setActiveTab('create')}
          className={`flex items-center px-4 py-2 rounded-lg ${
            activeTab === 'create'
              ? 'bg-blue-600 text-white'
              : 'bg-navy-700 text-gray-300 hover:bg-navy-600'
          }`}
        >
          <PlusCircle className="w-5 h-5 mr-2" />
          Create Exam
        </button>
        <button
          onClick={() => setActiveTab('templates')}
          className={`flex items-center px-4 py-2 rounded-lg ${
            activeTab === 'templates'
              ? 'bg-blue-600 text-white'
              : 'bg-navy-700 text-gray-300 hover:bg-navy-600'
          }`}
        >
          <Book className="w-5 h-5 mr-2" />
          Templates
        </button>
        <button
          onClick={() => setActiveTab('results')}
          className={`flex items-center px-4 py-2 rounded-lg ${
            activeTab === 'results'
              ? 'bg-blue-600 text-white'
              : 'bg-navy-700 text-gray-300 hover:bg-navy-600'
          }`}
        >
          <FileText className="w-5 h-5 mr-2" />
          Results
        </button>
        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex items-center px-4 py-2 rounded-lg ${
            activeTab === 'analytics'
              ? 'bg-blue-600 text-white'
              : 'bg-navy-700 text-gray-300 hover:bg-navy-600'
          }`}
        >
          <BarChart2 className="w-5 h-5 mr-2" />
          Analytics
        </button>
      </div>

      {activeTab === 'create' ? (
        <div className="bg-navy-800 rounded-lg p-6 shadow-xl">
          <h2 className="text-2xl font-bold text-white mb-6">Create New Exam</h2>
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Exam Title
                </label>
                <input
                  type="text"
                  value={examSettings.title}
                  onChange={(e) => setExamSettings({ ...examSettings, title: e.target.value })}
                  className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                  placeholder="Enter exam title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Category
                </label>
                <select
                  value={examSettings.category}
                  onChange={(e) => setExamSettings({ ...examSettings, category: e.target.value })}
                  className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                >
                  <option value="GenAI">Generative AI</option>
                  <option value="ML">Machine Learning</option>
                  <option value="DL">Deep Learning</option>
                  <option value="ANN">Neural Networks</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Duration (minutes)
                </label>
                <div className="flex items-center">
                  <Timer className="w-5 h-5 text-gray-400 mr-2" />
                  <input
                    type="number"
                    value={examSettings.duration}
                    onChange={(e) => setExamSettings({ ...examSettings, duration: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                    placeholder="60"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Schedule Date & Time
                </label>
                <input
                  type="datetime-local"
                  value={examSettings.startTime}
                  onChange={(e) => setExamSettings({ ...examSettings, startTime: e.target.value })}
                  className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Difficulty
                </label>
                <select
                  value={examSettings.difficulty}
                  onChange={(e) => setExamSettings({ ...examSettings, difficulty: e.target.value })}
                  className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
            </div>

            <div className="bg-navy-700 p-4 rounded-lg">
              <div className="flex items-center mb-4">
                <Settings className="w-5 h-5 text-blue-400 mr-2" />
                <h3 className="text-lg font-medium text-white">Advanced Settings</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Passing Score (%)
                  </label>
                  <input
                    type="number"
                    value={examSettings.passingScore}
                    onChange={(e) => setExamSettings({ ...examSettings, passingScore: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Time per Question (minutes)
                  </label>
                  <input
                    type="number"
                    value={examSettings.timePerQuestion}
                    onChange={(e) => setExamSettings({ ...examSettings, timePerQuestion: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={examSettings.allowReview}
                      onChange={(e) => setExamSettings({ ...examSettings, allowReview: e.target.checked })}
                      className="mr-2"
                    />
                    <span className="text-gray-300">Allow answer review</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={examSettings.shuffleQuestions}
                      onChange={(e) => setExamSettings({ ...examSettings, shuffleQuestions: e.target.checked })}
                      className="mr-2"
                    />
                    <span className="text-gray-300">Shuffle questions</span>
                  </label>
                </div>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={examSettings.showProgress}
                      onChange={(e) => setExamSettings({ ...examSettings, showProgress: e.target.checked })}
                      className="mr-2"
                    />
                    <span className="text-gray-300">Show progress bar</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={examSettings.preventTabSwitch}
                      onChange={(e) => setExamSettings({ ...examSettings, preventTabSwitch: e.target.checked })}
                      className="mr-2"
                    />
                    <span className="text-gray-300">Prevent tab switching</span>
                  </label>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Questions
              </label>
              <div className="space-y-4">
                {questions.map((question, index) => (
                  <div key={index} className="bg-navy-700 p-4 rounded-lg">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Question Text
                        </label>
                        <input
                          type="text"
                          value={question.text}
                          onChange={(e) => handleQuestionChange(index, 'text', e.target.value)}
                          className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                          placeholder="Enter question text"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            Difficulty
                          </label>
                          <select
                            value={question.difficulty}
                            onChange={(e) => handleQuestionChange(index, 'difficulty', e.target.value)}
                            className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                          >
                            <option value="easy">Easy</option>
                            <option value="medium">Medium</option>
                            <option value="hard">Hard</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            Points
                          </label>
                          <input
                            type="number"
                            value={question.points}
                            onChange={(e) => handleQuestionChange(index, 'points', parseInt(e.target.value))}
                            className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {question.options.map((option, optionIndex) => (
                        <div key={optionIndex} className="flex items-center">
                          <input
                            type="radio"
                            name={`correct-${index}`}
                            checked={question.correctAnswer === optionIndex}
                            onChange={() => handleQuestionChange(index, 'correctAnswer', optionIndex)}
                            className="mr-2"
                          />
                          <input
                            type="text"
                            value={option}
                            onChange={(e) => {
                              const newOptions = [...question.options];
                              newOptions[optionIndex] = e.target.value;
                              handleQuestionChange(index, 'options', newOptions);
                            }}
                            className="flex-1 px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                            placeholder={`Option ${optionIndex + 1}`}
                          />
                        </div>
                      ))}
                    </div>
                    <div className="mt-4">
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Explanation (shown after answering)
                      </label>
                      <textarea
                        value={question.explanation}
                        onChange={(e) => handleQuestionChange(index, 'explanation', e.target.value)}
                        className="w-full px-3 py-2 bg-navy-900 border border-navy-600 rounded-md text-white"
                        rows={2}
                        placeholder="Explain the correct answer..."
                      />
                    </div>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={handleAddQuestion}
                  className="w-full py-2 px-4 bg-navy-700 text-white rounded-md hover:bg-navy-600 flex items-center justify-center"
                >
                  <PlusCircle className="w-5 h-5 mr-2" />
                  Add Question
                </button>
              </div>
            </div>

            <div className="flex space-x-4">
              <button
                type="submit"
                className="flex-1 py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition duration-200"
              >
                Schedule Exam
              </button>
              <button
                type="button"
                onClick={handleSaveTemplate}
                className="py-2 px-4 bg-green-600 hover:bg-green-700 text-white rounded-md transition duration-200"
              >
                Save as Template
              </button>
            </div>
          </form>
        </div>
      ) : activeTab === 'templates' ? (
        <div className="bg-navy-800 rounded-lg p-6 shadow-xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">Exam Templates</h2>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Import Template
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {examTemplates.map(template => (
              <div key={template.id} className="bg-navy-700 p-4 rounded-lg">
                <h3 className="text-lg font-bold mb-2">{template.title}</h3>
                <div className="text-sm text-gray-300 space-y-1">
                  <p>Category: {template.category}</p>
                  <p>Questions: {template.questions.length}</p>
                  <p>Duration: {template.duration} minutes</p>
                </div>
                <div className="mt-4 flex space-x-2">
                  <button className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">
                    Use
                  </button>
                  <button className="px-3 py-1 bg-navy-600 text-white rounded hover:bg-navy-500">
                    Edit
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : activeTab === 'analytics' ? (
        renderAnalytics()
      ) : (
        <div className="bg-navy-800 rounded-lg p-6 shadow-xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-white">Results Analysis</h2>
            <button
              onClick={handleDownloadResults}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              <Download className="w-5 h-5 mr-2" />
              Download Results
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-navy-700 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <Users className="w-6 h-6 text-blue-400" />
                <span className="text-2xl font-bold text-white">156</span>
              </div>
              <p className="text-gray-300">Total Students</p>
            </div>
            <div className="bg-navy-700 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <FileText className="w-6 h-6 text-blue-400" />
                <span className="text-2xl font-bold text-white">12</span>
              </div>
              <p className="text-gray-300">Active Exams</p>
            </div>
            <div className="bg-navy-700 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <Clock className="w-6 h-6 text-blue-400" />
                <span className="text-2xl font-bold text-white">85%</span>
              </div>
              <p className="text-gray-300">Average Score</p>
            </div>
          </div>

          <div className="bg-navy-900 rounded-lg overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-navy-700">
                <tr>
                  <th className="px-6 py-3 text-gray-300">Student Name</th>
                  <th className="px-6 py-3 text-gray-300">Exam Title</th>
                  <th className="px-6 py-3 text-gray-300">Date</th>
                  <th className="px-6 py-3 text-gray-300">Score</th>
                  <th className="px-6 py-3 text-gray-300">Time Taken</th>
                  <th className="px-6 py-3 text-gray-300">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-navy-700">
                <tr className="text-gray-300">
                  <td className="px-6 py-4">John Doe</td>
                  <td className="px-6 py-4">GenAI Fundamentals</td>
                  <td className="px-6 py-4">2024-03-15</td>
                  <td className="px-6 py-4">92%</td>
                  <td className="px-6 py-4">45 minutes</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-green-600/20 text-green-400 rounded">Passed</span>
                  </td>
                </tr>
                <tr className="text-gray-300">
                  <td className="px-6 py-4">Jane Smith</td>
                  <td className="px-6 py-4">ML Basics</td>
                  <td className="px-6 py-4">2024-03-14</td>
                  <td className="px-6 py-4">88%</td>
                  <td className="px-6 py-4">52 minutes</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 bg-green-600/20 text-green-400 rounded">Passed</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}