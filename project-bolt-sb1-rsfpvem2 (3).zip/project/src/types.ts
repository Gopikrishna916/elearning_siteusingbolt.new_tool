export interface User {
  id: string;
  email: string;
  role: 'student' | 'employee';
  name: string;
  verified: boolean;
  enrolledCourses: string[];
  completedCourses: string[];
  certificates: Certificate[];
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
}

export interface Exam {
  id: string;
  title: string;
  duration: number;
  questions: Question[];
  startTime: string;
  endTime: string;
  passingScore: number;
  category: string;
  allowReview: boolean;
  shuffleQuestions: boolean;
  preventTabSwitch: boolean;
  requireWebcam: boolean;
}

export interface ExamResult {
  id: string;
  studentId: string;
  examId: string;
  score: number;
  answers: number[];
  completedAt: string;
  timeTaken: number;
  passed: boolean;
}

export interface Certificate {
  id: string;
  userId: string;
  courseId: string;
  courseName: string;
  issueDate: string;
  certificateNumber: string;
  signedBy: string;
  grade: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  modules: Module[];
  duration: number;
  level: 'beginner' | 'intermediate' | 'advanced';
  prerequisites: string[];
  instructor: string;
}

export interface Module {
  id: string;
  title: string;
  description: string;
  content: string;
  videoUrl: string;
  exercises: Exercise[];
  quizzes: Quiz[];
  duration: number;
}

export interface Exercise {
  id: string;
  title: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
  solution: string;
}

export interface Quiz {
  id: string;
  title: string;
  questions: Question[];
  duration: number;
  passingScore: number;
}