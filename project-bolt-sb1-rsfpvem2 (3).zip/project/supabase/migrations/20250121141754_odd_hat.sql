/*
  # Enhanced Security Features

  1. Changes
    - Add user verification system
    - Add session tracking
    - Add audit logging
    - Add rate limiting for exam attempts
    - Add IP tracking for security

  2. Security
    - Enhanced RLS policies
    - Additional constraints
    - Audit trail
*/

-- Session tracking
CREATE TABLE IF NOT EXISTS user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  ip_address text NOT NULL,
  user_agent text,
  started_at timestamptz DEFAULT now(),
  ended_at timestamptz,
  is_active boolean DEFAULT true
);

-- Audit logging
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  old_data jsonb,
  new_data jsonb,
  ip_address text,
  created_at timestamptz DEFAULT now()
);

-- Rate limiting for exam attempts
CREATE TABLE IF NOT EXISTS exam_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  exam_id uuid REFERENCES exams(id),
  attempt_count integer DEFAULT 1,
  last_attempt_at timestamptz DEFAULT now(),
  UNIQUE(user_id, exam_id)
);

-- Add verification codes table
CREATE TABLE IF NOT EXISTS verification_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  code text NOT NULL,
  type text NOT NULL,
  expires_at timestamptz NOT NULL,
  used boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_codes ENABLE ROW LEVEL SECURITY;

-- Enhanced RLS Policies

-- User Sessions
CREATE POLICY "Users can only view their own sessions"
  ON user_sessions
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Audit Logs
CREATE POLICY "Users can view their own audit logs"
  ON audit_logs
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Exam Attempts
CREATE POLICY "Users can view their own exam attempts"
  ON exam_attempts
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Functions for security

-- Function to log audit events
CREATE OR REPLACE FUNCTION log_audit_event(
  p_user_id uuid,
  p_action text,
  p_entity_type text,
  p_entity_id uuid,
  p_old_data jsonb,
  p_new_data jsonb
) RETURNS void AS $$
BEGIN
  INSERT INTO audit_logs (
    user_id, action, entity_type, entity_id, old_data, new_data, ip_address
  )
  VALUES (
    p_user_id,
    p_action,
    p_entity_type,
    p_entity_id,
    p_old_data,
    p_new_data,
    current_setting('request.headers')::json->>'x-forwarded-for'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to check exam attempt limits
CREATE OR REPLACE FUNCTION check_exam_attempt_limit(
  p_user_id uuid,
  p_exam_id uuid,
  p_max_attempts integer DEFAULT 3
) RETURNS boolean AS $$
DECLARE
  v_attempts integer;
BEGIN
  SELECT attempt_count
  INTO v_attempts
  FROM exam_attempts
  WHERE user_id = p_user_id AND exam_id = p_exam_id;

  IF v_attempts IS NULL THEN
    INSERT INTO exam_attempts (user_id, exam_id)
    VALUES (p_user_id, p_exam_id);
    RETURN true;
  ELSIF v_attempts < p_max_attempts THEN
    UPDATE exam_attempts
    SET attempt_count = attempt_count + 1,
        last_attempt_at = now()
    WHERE user_id = p_user_id AND exam_id = p_exam_id;
    RETURN true;
  ELSE
    RETURN false;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to verify user
CREATE OR REPLACE FUNCTION verify_user(
  p_user_id uuid,
  p_code text
) RETURNS boolean AS $$
DECLARE
  v_valid boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM verification_codes
    WHERE user_id = p_user_id
    AND code = p_code
    AND type = 'verification'
    AND NOT used
    AND expires_at > now()
  ) INTO v_valid;

  IF v_valid THEN
    UPDATE users SET verified = true WHERE id = p_user_id;
    UPDATE verification_codes
    SET used = true
    WHERE user_id = p_user_id AND code = p_code;
    RETURN true;
  ELSE
    RETURN false;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Triggers for security

-- Trigger to log user actions
CREATE OR REPLACE FUNCTION audit_trigger_func() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    PERFORM log_audit_event(
      auth.uid(),
      'INSERT',
      TG_TABLE_NAME::text,
      NEW.id,
      NULL,
      to_jsonb(NEW)
    );
  ELSIF TG_OP = 'UPDATE' THEN
    PERFORM log_audit_event(
      auth.uid(),
      'UPDATE',
      TG_TABLE_NAME::text,
      NEW.id,
      to_jsonb(OLD),
      to_jsonb(NEW)
    );
  ELSIF TG_OP = 'DELETE' THEN
    PERFORM log_audit_event(
      auth.uid(),
      'DELETE',
      TG_TABLE_NAME::text,
      OLD.id,
      to_jsonb(OLD),
      NULL
    );
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add audit triggers to important tables
CREATE TRIGGER audit_users_trigger
  AFTER INSERT OR UPDATE OR DELETE ON users
  FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();

CREATE TRIGGER audit_exams_trigger
  AFTER INSERT OR UPDATE OR DELETE ON exams
  FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();

CREATE TRIGGER audit_exam_results_trigger
  AFTER INSERT OR UPDATE OR DELETE ON exam_results
  FOR EACH ROW EXECUTE FUNCTION audit_trigger_func();

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_exam_attempts_user_exam ON exam_attempts(user_id, exam_id);
CREATE INDEX IF NOT EXISTS idx_verification_codes_user_id ON verification_codes(user_id);