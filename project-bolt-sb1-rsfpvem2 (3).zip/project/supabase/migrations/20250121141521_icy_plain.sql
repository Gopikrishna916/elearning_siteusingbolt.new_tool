/*
  # Initial Schema Setup

  1. New Tables
    - users
    - courses
    - modules
    - exams
    - exam_results
    - certificates
    - enrollments

  2. Security
    - Enable RLS on all tables
    - Add policies for data access
*/

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'employee')),
  verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Courses table
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  duration integer NOT NULL,
  level text CHECK (level IN ('beginner', 'intermediate', 'advanced')),
  prerequisites text[],
  instructor text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Modules table
CREATE TABLE IF NOT EXISTS modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id),
  title text NOT NULL,
  description text,
  content text,
  video_url text,
  duration integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Exams table
CREATE TABLE IF NOT EXISTS exams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  course_id uuid REFERENCES courses(id),
  duration integer NOT NULL,
  questions jsonb NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  passing_score integer NOT NULL,
  category text NOT NULL,
  allow_review boolean DEFAULT true,
  shuffle_questions boolean DEFAULT false,
  prevent_tab_switch boolean DEFAULT true,
  require_webcam boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Exam results table
CREATE TABLE IF NOT EXISTS exam_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES users(id),
  exam_id uuid REFERENCES exams(id),
  score numeric NOT NULL,
  answers jsonb NOT NULL,
  time_taken integer NOT NULL,
  passed boolean NOT NULL,
  completed_at timestamptz DEFAULT now()
);

-- Certificates table
CREATE TABLE IF NOT EXISTS certificates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  course_id uuid REFERENCES courses(id),
  certificate_number text UNIQUE NOT NULL,
  grade text NOT NULL,
  issue_date timestamptz DEFAULT now()
);

-- Enrollments table
CREATE TABLE IF NOT EXISTS enrollments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  course_id uuid REFERENCES courses(id),
  status text CHECK (status IN ('enrolled', 'completed', 'dropped')),
  enrolled_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  UNIQUE(user_id, course_id)
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE exam_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE enrollments ENABLE ROW LEVEL SECURITY;

-- RLS Policies

-- Users policies
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Courses policies
CREATE POLICY "Anyone can view courses"
  ON courses
  FOR SELECT
  TO authenticated
  USING (true);

-- Modules policies
CREATE POLICY "Enrolled students can view modules"
  ON modules
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE user_id = auth.uid()
      AND course_id = modules.course_id
    )
  );

-- Exams policies
CREATE POLICY "Students can view available exams"
  ON exams
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM enrollments
      WHERE user_id = auth.uid()
      AND course_id = exams.course_id
    )
  );

-- Exam results policies
CREATE POLICY "Students can view own results"
  ON exam_results
  FOR SELECT
  TO authenticated
  USING (student_id = auth.uid());

-- Certificates policies
CREATE POLICY "Students can view own certificates"
  ON certificates
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Enrollments policies
CREATE POLICY "Students can view own enrollments"
  ON enrollments
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());